#!/bin/sh
echo "This is a scheduled task" >> ./test.log
